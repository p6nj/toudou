from .main import click
from pickle import load, dump


@click.command("import")
def _import():
    pass
