import click
from .create import new
from .delete import delete
from .read import show
from .update import rename, markdone, markundone
from sqlite3 import connect
from sys import exit


def main():
    try:
        cli(obj=connect("td.db").cursor())
    except Exception as e:
        print(e)
        exit(0)


@click.group()
@click.pass_context
def cli(ctx):
    """Todo list manager (command-line version)."""
    ctx.obj.executescript(open("td.sql", "r").read())


cli.add_command(new)
cli.add_command(delete)
cli.add_command(show)
cli.add_command(rename)
cli.add_command(markdone)
cli.add_command(markundone)
